# VUE \ Language Understanding (LUIS) \ THREE.JS

To install dependencies and run a local server:
YARN:
yarn
yarn serve

NPM:
npm install
npm run serve

to create a static copy run
npm run build

project runs at local store: `localhost:8080`.

Technologies used:
Language Understanding (LUIS) https://www.luis.ai/
vuejs
three.js
Microsoft Azure
axios
sinewaves
